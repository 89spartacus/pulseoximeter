// --- [ global.h ] -----------------------------------------------------------

#define TRUE   				1
#define FALSE     			0
#define DEZIMAL_PUNKT 		','
#define SEPARATOR				';'

#ifndef EXTERN
#define EXTERN extern
#endif

// Grundeinstellungen, die w�hrend des Betriebes ge�ndert werden k�nnen
#define PAUSE					60			// Anzahl Sekunden zwischen den Messungen
#define SLEEP_MODE			FALSE		// Sleepmode ein/aus
#define LED_MODE				TRUE		// Kontroll-LED ein/aus
#define RS232_MODE			TRUE		// DatenAusgabe via RS232
#define SWITCH_MODE			FALSE		// Schaltfunktionen ein/aus

// PD5/T1 ist unver�nderbarer Input f�r den Counter !!!

#define ALARM_PORT			PORTD
#define INT0_PORT				PORTD
#define INT0_PORT_IN			PIND
#define ALARM_DDR				DDRD
#define ALARM_PIN_1			PD3
#define ALARM_PIN_2			PD4
#define INT0_PIN				PD2

#define LED_PORT				PORTD
#define LED_PIN				PD6

#define ALARM_1_SET			ALARM_PORT |=   (1<<ALARM_PIN_1)		
#define ALARM_1_CLR			ALARM_PORT &= (~(1<<ALARM_PIN_1))

#define ALARM_2_SET			ALARM_PORT |=   (1<<ALARM_PIN_2)		
#define ALARM_2_CLR			ALARM_PORT &= (~(1<<ALARM_PIN_2))

// einige volatile Variablen sind in die freien GPIO-Register verlegt
// Das reduziert den Programm-Speicherbedarf ....

// siehe lokale Variablen TSL230.c
//#define timer0_busy_flag EEDR			// Die Flags in ungenutzte Register verlegen,
//#define timer1_ovf_flag  EEAR			// spart 10 Byte.

#define USI_TWI_State 				GPIOR0
#define INT_Activity_Flag			GPIOR1
#define rx_flag						GPIOR2

// INT_Activity_Flag states:
#define INT_NO_ACTIVITY				1
#define INT_ACTIVITY					0



// --- [ eof ] ----------------------------------------------------------------