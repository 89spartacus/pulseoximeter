// --- [ TSL230.c ] -----------------------------------------------------------
//
//       tab = 3

#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdlib.h>
#include <util/delay.h>
#include "TSL230.h"
#include "global.h"
#include "USI_TWI_slave_c.h"

// Am TSL230 ist das Scaling auf 1 voreingestellt
// Variiert werden zun�chst die Sensitivity in den Stufen 1 / 10 /100 
// Bei hoher Helligkeit wird Scaling = 2 gew�hlt
// Die anderen Scaling-Faktoren werden nicht genutzt
// Das Messintervall ist fest mit 0.1 Sekunde eingestellt

// --- lokale Funktionen ------------------------------------------------------
void TSL_Start_Counting(void);
void TSL_Set_Sensitivity(uint8_t s);
void TSL_Set_Scaling(uint8_t s);

// --- lokale Variablen -------------------------------------------------------

uint8_t sensitivity;							// speichert die Einstellung f�r Sensitivity
uint8_t scaling;								// und Scaling

//volatile uint8_t timer0_busy_flag;	// Flag und Counter f�r Timer0 (Messintervall)
//volatile uint8_t timer1_ovf_flag;		// Flag f�r �berlauf des Counter1

#define timer0_busy_flag 	EEDR			// Die Flags in ungenutzte Register verlegen,
#define timer1_ovf_flag    EEAR			// spart 10 Byte.

// ----------------------------------------------------------------------------
// Initialisiert die Portpins und Grundeinstellung f�r den TSL230
void TSL_Init(void)
{
TSL_DDR |= (1<<TSL_S0_PIN | 1<<TSL_S1_PIN | 1<<TSL_S2_PIN | 1<<TSL_S3_PIN );
TSL_Set_Scaling(TSL_SCALING_1);
TSL_Set_Sensitivity(TSL_SENSITIVITY_1);
}

// ----------------------------------------------------------------------------
// F�hrt eine Messung der Beleuchtungsst�rke durch:
// Beginnt mit dem k�rzesten Zeitintervall und pr�ft
// - ob der Counter �bergelaufen ist (genaugenommen: beinahe w�re)
//   falls ja, dann wird die Sensitivity reduziert
// - ist der Z�hlerstand < 2048, dann
//   wird die Sensitivity vergr��ert.
// Am Ende wird der 16-Bit Counter zur�ckgeliefert
// Vor der R�ckgabe des Counters sind noch die Korrekturfaktoren zu ber�cksichtigen.

//uint16_t TSL_Count(void)
void TSL_Count(uint32_t* cnt32, uint8_t * teiler)
{
uint8_t cnt_high, cnt_low;

TSL_Start_Counting();							// wartet bis das Messintervall abgelaufen
														// setzt bei Counter1-�berlauf timer1_ovf_flag

while (timer1_ovf_flag)							// wenn der �berlauf droht, dann
	{
														// wenn bereits der Divisor 2 gesetzt ist,
//	if (scaling > TSL_SCALING_1) break;		// dann wird beendet
// Macht keinen Sinn, denn das sollte nicht passieren

	if(sensitivity > TSL_SENSITIVITY_1) 	// die Empfindlichkeit reduzieren
		{
		TSL_Set_Sensitivity( sensitivity / 10 ); // Die Sensitivity ist 1/10/100
		}

	else 												// wenn das nicht mehr geht, 
		{												// dann die Frequenz durch 2 dividieren lassen
		TSL_Set_Scaling(TSL_SCALING_2);
		}

	TSL_Start_Counting();						// neu messen und neu testen
	}

cnt_low   = TCNT1L;										// den Messwert einlesen
cnt_high  = TCNT1H;


while (cnt_high < 16)								// wenn der Wert < 4096 (das High-Byte < 16)
	{													
														// Abbruch, wenn bereits die h�chste Aufl�sung erreicht ist
														// dann ist es wirklich einfach nur dunkel !!!
	if ((scaling == TSL_SCALING_1) && (sensitivity == TSL_SENSITIVITY_100)) break;
	
	// Zuerst das Scaling zur�cknehmen - falls gesetzt
	if (scaling > TSL_SCALING_1) TSL_Set_Scaling(TSL_SCALING_1);
														// danach versuchen, die Empfindlichkeit erh�hen
	else if (sensitivity < TSL_SENSITIVITY_100) TSL_Set_Sensitivity( sensitivity * 10 );
	
	TSL_Start_Counting();						// neue Messung ansto�en und warten 
														// bis das Messintervall abgelaufen ist
	cnt_low   = TCNT1L;							// Messwert holen
	cnt_high  = TCNT1H;
	}


// den Messwert aus den beiden Bytes zusammenf�gen
*cnt32  = (uint16_t)(cnt_high << 8) + cnt_low;

// falls scaling == 2, dann mit 2 multiplizieren
if (scaling == 2) (*cnt32 <<= 1); 

//*cnt32 /= sensitivity;
// Die Ganzzahl-Division wird der aufrufenden Routine �berlassen
// Dadurch k�nnen bei Bedarf die Nachkommastellen ausgewertet werden.

*teiler = sensitivity;						   // aber der Teiler muss zur�ckgeliefert werden

}

// ----------------------------------------------------------------------------
// Startet Timer0 f�r das Messintervall (0.1 Sekunden) und Timer1 als 16-Bit Counter
// Ein drohender �berlauf des Counter1 wird durch einen CompareA-Match erkannt und mit
// dem Flag timer1_ovf_flag signalisiert

// Timer0: CPU: 3686400, Prescale 256, CompareA 144 -> (144 * 256) / 3686400 = 1/100 Sekunde

// Wenn w�hrend der Messung RX/USI-Interrupts aufgerufen werden, dann kann dadurch das Messintervall
// verl�ngert worden sein.
// Um dadurch entstehende Messfehler zu vermeiden, wird �ber das Flag USI_activity_flag gepr�ft, 
// ob eine RX/USI-Aktion stattgefunden hat.
// Wenn ja, dann wird eine neue Messung ausgef�hrt.
void TSL_Start_Counting(void)

{
do {
	INT_Activity_Flag  = FALSE;
	timer0_busy_flag = 10; 						// wird bei jedem Compare_Match heruntergez�hlt
	timer1_ovf_flag  = FALSE;					// signalisiert den drohenden Overflow des Counter1

	TCNT0  = 0;										// Counter0 zur�cksetzen
	OCR0A  = 144 - 1;  							// Compare-Wert f�r 0.01 Sekunde 
														// fo = F_CPU / (2 * PRESCALE * (1 + OCR0A))
	TCCR0A = (1<<WGM01);							// Timer0: CTC-Modus
	
	TCNT1H = 0;										// Counter1 zur�cksetzen
	TCNT1L = 0;
	OCR1AH = 255;									// Compare-Wert f�r Counter1
	OCR1AL = 254;
														// Nun die Timer starten
														// Damit hier kein Interrupt auftreten kann:
	cli();
	TCCR0B = (1<<CS02 | 0<<CS01 | 0<<CS00);// Timer0: Prescale 256
	TCCR1B = (1<<CS12 | 1<<CS11 | 1<<CS10);// Timer1: External Clock
	sei();

	TIMSK |= (1<<OCIE1A | 1<<OCIE0A); 		// COMPA-Interrupts f�r Timer0 und Timer1
	
	while(timer0_busy_flag);					// warten bis zum Ende des Messintervalls 
														// oder einem drohenden �berlauf von Counter1
	} while (INT_Activity_Flag);				// neue Messung, wenn zwischendrin USI-/Rx-Aktivit�t
}

// ----------------------------------------------------------------------------
// Stellt die Skalierung des Messwertes �ber die beiden Pins S2/S3 am TSL230 ein.
// Speichert den Wert in der Variablen scaling.
//
// Das Programm arbeitet fast ausschlie�lich mit Scaling = 1.
// Nur bei extremer Helligkeit wird Scaling = 2 verwendet.
void TSL_Set_Scaling(uint8_t s)
{
uint8_t i;

i = scaling;									// den aktuellen Wert sichern
scaling = s;									// den gew�nschten Wert vorgeben
if (s == TSL_SCALING_1)
	{
	TSL_PORT &= (~(1<<TSL_S2_PIN | 1<<TSL_S3_PIN));	// beide Pins l�schen
	}
else if (s == TSL_SCALING_2)	
	{
	TSL_PORT |=   (1<<TSL_S2_PIN);		// Pin setzen
	TSL_PORT &= (~(1<<TSL_S3_PIN));		// Pin l�schen
	}
else if (s == TSL_SCALING_10)	
	{
	TSL_PORT |=   (1<<TSL_S3_PIN);		// Pin setzen
	TSL_PORT &= (~(1<<TSL_S2_PIN));		// Pin l�schen
	}
else if (s == TSL_SCALING_100)	
	{
	TSL_PORT |=  ((1<<TSL_S2_PIN) |  (1<<TSL_S3_PIN));	// beide Pins setzen
	}
else scaling = i;								// bei falschem Parameter den alten
}													// Wert wieder herstellen

// ----------------------------------------------------------------------------
// Stellt die Empfindlichkeit �ber die beiden Pins SO/S1 am TSL230 ein.
// Speichert den Wert in der Variablen sensitivity.
void TSL_Set_Sensitivity(uint8_t s)
{
uint8_t i;
i = sensitivity;								// den alten Wert speichern

sensitivity = s;

if (s == TSL_SENSITIVITY_1)
	{
	TSL_PORT |=   (1<<TSL_S0_PIN);		// Pin setzen
	TSL_PORT &= (~(1<<TSL_S1_PIN));		// Pin l�schen
	}
else if (s == TSL_SENSITIVITY_10)
	{
	TSL_PORT |=   (1<<TSL_S1_PIN);		// Pin setzen
	TSL_PORT &= (~(1<<TSL_S0_PIN));		// Pin l�schen
	}
else if (s == TSL_SENSITIVITY_100)
	{
	TSL_PORT |=  ((1<<TSL_S0_PIN) |  (1<<TSL_S1_PIN));	// beide Pins setzen
	}
else if (s == TSL_SENSITIVITY_PD)
	{
	TSL_PORT &= (~((1<<TSL_S0_PIN) | (1<<TSL_S1_PIN)));	// beide Pins l�schen
	}
else sensitivity = i;						// bei falschem Parameter den alten
}													// Wert wieder herstellen

// ----------------------------------------------------------------------------
// schaltet den TSL in den PowerDown-Modus,
// die typische Stromaufnahme f�llt von 2mA auf 5uA.
// rettet den bestehenden Sensitivity-Wert.
void TSL_Power_Down(void)
{
uint8_t i;
i = sensitivity;
TSL_Set_Sensitivity(TSL_SENSITIVITY_PD);
sensitivity = i;
}

// ----------------------------------------------------------------------------
// Start den TSL wieder mit dem letzten Sensitivity-Wert,
// der in der Variablen sensitivity beim TSL_Power_Down gesichert wurde.
void TSL_Power_Up(void)
{
TSL_Set_Sensitivity(sensitivity);

// laut Datenblatt betr�gt die Recoverytime from Power-Down 100us
_delay_us(150);
}

// ----------------------------------------------------------------------------
// Wird aufgerufen, kurz bevor der Counter bei 2^16 �berl�uft.
// Es muss ein k�rzerer Messzeitraum oder eine andere Einstellung f�r Scaling
// oder Sensitivity am TSL230 vorgenommen werden.
// Stoppt die Timer und setzt das Flag cnt_ovf.

ISR(TIMER1_COMPA_vect)
{
	TCCR0B   = 0;									// beide Timer abschalten
	TCCR1B   = 0;
	timer1_ovf_flag  = TRUE;					// signalisiert den Overflow
	timer0_busy_flag = FALSE;					// beendet das Messintervall
}

// ----------------------------------------------------------------------------
// wird im Abstand von 0.01 Sekunden aufgerufen und decrementiert den Z�hler timer0_busy_flag.
// Hat dieser Null erreicht, werden alle Timer und Counter gestoppt.
ISR(TIMER0_COMPA_vect)
{
timer0_busy_flag--;
if (!(timer0_busy_flag))
	{
	TCCR0B = 0;										// beide Timer abschalten
	TCCR1B = 0;	
	}
}

// --- [eof ] -----------------------------------------------------------------