// --- [ TSL230_main.c ] ------------------------------------------------------
//       tab = 3
//       15.07.2011

#define EXTERN

#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdlib.h>
#include <util/delay.h>
#include "global.h"
#include "TSL230.h"
#include "rs232_read_c.h"
#include "USI_TWI_slave_c.h"

#define CMD_SLEEP			1
#define CMD_PAUSE			2
#define CMD_RS232			3
#define CMD_LED			4
#define CMD_SWITCH		5
#define CMD_LIMIT_1		1
#define CMD_LIMIT_2		2

#define INT0_ACTIV	TRUE						// Unterbrechung des Sleep durch 
														// den INT0-Interrupt erm�glichen.
#define DEBUG			FALSE						// Ausgabe aktueller Einstellung aktivieren
#define SWITCH			FALSE						// Schaltfunktionen aktivieren

														// Unterschiedliche Ausgabeformate f�r die 
														// Serielle Schnittstelle
														// Der SRAM-Bedarf ist bei 1) am kleinsten,
														// bei 5) am gr��ten (Unterschied > 300 Byte !)
#define BINAER				1						// bin�r in 4 Byte
#define BYTES_CSV			2						// Bytes als Zeichenfolge (Dezimaldarstellung, Kommasepariert)
#define STRING_16			3						// als String in Lux mit Begrenzung auf 2^16
#define STRING_32			4						// als String in Lux (32-Bit)
#define DEZ_STRING		5						// als String in Lux (32-Bit) mit Dezimalstellen
#define EXPORT		DEZ_STRING					// ausgew�hltes Ausgabeformat (DEZ_STRING ben�tigt viel SRAM !!)

// --- Lokale Variablen ------------------------------------------------------
char cv[10];										// f�r utoa()
uint32_t cnt32;									

uint8_t delay_1s(uint8_t t);					// Warteschleife - kann durch IRQ beendet werden 
void Dez_Punkt(uint8_t n);						// f�gt einen Dezimalpunkt in String ein

// ----------------------------------------------------------------------------
int main( void )
{
uint8_t rx_data[RX_BUFFER_SIZE];
uint8_t buffer[RX_BUFFER_SIZE];
uint8_t i, teiler;
uint16_t cnt;
uint8_t measure_flag = FALSE;					// nur f�r den internen Gebrauch
int8_t rx; 
										
uint8_t pause        = PAUSE;					// Voreinstellung - von aussen ver�nderbar
uint8_t sleep_flag   = SLEEP_MODE;			// siehe global.h
uint8_t RS232_flag   = RS232_MODE;
uint8_t LED_flag     = LED_MODE;
uint8_t switch_flag  = SWITCH_MODE;

#if SWITCH == TRUE
uint16_t cnt;
uint16_t Limit_1_min = 50, Limit_1_max = 140;
uint16_t Limit_2_min = 120, Limit_2_max = 500;
ALARM_DDR  = (1<<ALARM_PIN_1 | 1<<ALARM_PIN_2 | 1<<LED_PIN);

#else
ALARM_DDR  = (1<<LED_PIN);						// nur den Ausgang f�r die LED setzen

#endif

ALARM_PORT = (1<<INT0_PIN | 1<<LED_PIN);	// Pullup f�r INT0-Pin aktivieren
														// Led ausschalten
RS232_init();
USI_TWI_Slave_Initialise();
asm volatile("sei");	 							// enable_interrupt
														// Sleep-Modus konfigurieren
MCUCR = (1<<SE | 1<<SM1 | 1<<SM0); 			// Powerdown und Sleep Enable
ACSR = (1<<ACD);									// Analog Comparator Disable
TSL_Init();

put_c(13);											// durch Senden eines Bytes wird das Flag UCSRA -> TXC gesetzt
														// ist f�r den Eintritt ins "sleep" notwendig, wenn zuvor
														// keine Daten via RS232 versandt wurden (wenn RS232_flag == FALSE).
while(1)	
	{
// --- Sind Daten via Serieller Schnittstelle eingegangen ? -------------------
	rx = RX_Received_Bytes();
	if (rx >= 0)									// wenn RETURN + ggf. Daten empfangen wurden
		{
		RX_Get_Data(rx_data);					// Daten holen und Counter zur�cksetzen !
		}

// -- oder sind Daten via TWI eingegangen ? -----------------------------------
	else
		{
		rx =	(USI_TWI_Received_Bytes()); 	// sind Daten im Puffer ?
		if (rx >= 0)								// wenn die TWI-Adresse ++ ggf. Daten empfangen wurden,
			{											// dann die Daten
			USI_TWI_Get_Data(rx_data); 		// aus dem Empfangspuffer holen und Counter zur�cksetzen
			}
		}

// 	alle Daten (sofern vorhanden) sind jetzt eingelesen in rx_data[]
// 	in rx steht die Anzahl der gelesenen Bytes
// 	Bei rx == 0 wurden Daten vom Master abgeholt (daher keine Daten empfangen)
//    	         oder nur ein RETURN via serieller Schnittstelle empfangen
// 	Bei rx == 2 k�nnte es sich um eine Einstellung handeln (Kommando + Parameter)
// 	Bei rx == 3 werden die Schaltschwellen etc. via Serieller Schnittstelle ausgegeben
// 	Bei rx == 5 k�nnten Schaltschwellen �bertragen werden

// --- Wenn genau 1 Byte empfangen wurde (das ist dann das RETURN via RS232 oder die g�ltige
//     TWI-Adresse via USI-TWI
//     Oder wenn measure_flag gesetzt worden ist, dann eine Messung ausf�hren 	

/*
put_c(13);
put_s(itoa(rx, cv,10));
put_c(13);

put_c('.');
put_s(utoa(rx_data[0], cv, 10));
put_c('.');
put_s(utoa(rx_data[1], cv, 10));
put_c('.');
put_s(utoa(rx_data[2], cv, 10));
put_c('.');
put_s(utoa(rx_data[3], cv, 10));
put_c('.');
put_s(utoa(rx_data[4], cv, 10));

put_c(13);
*/

// --- Eine neue Messung ausf�hren --------------------------------------------
	if ((rx == 0) || measure_flag)
		{
		measure_flag = FALSE;
		TSL_Power_Up();								// Den Sensor aufwecken, dabei 150us warten

		if (LED_flag) LED_PORT &= (~(1<<LED_PIN));// LED f�r die Dauer der Messung einschalten

		TSL_Count(&cnt32, &teiler);				// die Messung ausf�hren

		buffer[0] = (uint8_t) (cnt32 >> 16);	// die Daten exportieren
		buffer[1] = (uint8_t) (cnt32 >> 8);
		buffer[2] = (uint8_t)  cnt32;
		buffer[3] = teiler;

		USI_TWI_Transmit_Data(buffer, 4);		// Messwert ins USI-Modul exportieren
		TSL_Power_Down();								// den Sensor wieder in den Power-Down-Modus schicken
		
// --- wenn eine RS232-Ausgabe gew�nscht ist -----------------------------------
		if (RS232_flag)							
			{
	
#if EXPORT == BINAER
//			put_c(5);									// L�nge des Datensatzes incl. dieses Bytes
			for (i = 0; i < 4; i++)					// Ausgabe binaer
				{
				put_c(buffer[i]);
				}
				
#elif EXPORT == BYTES_CSV							// als CSV-Datei
			for (i = 0; i < 4; i++)					// Ausgabe byteweise dezimal/hexadezimal
				{
				put_s(utoa(buffer[i], cv, 10));
				put_c(SEPARATOR);						
				}
			put_c(13);

#elif EXPORT == STRING_16
															// Ausgabe als ASCII-Zeichenfolge
			cnt32 /= teiler;							// durch 1 / 10 / 100 teilen
		// Werte gr��er 2^16 reduzieren auf 2^16
		//	if (cnt32 & 0xFFFF0000) cnt = 0xFFFF; else cnt = (uint16_t) cnt32;
			if (buffer[0]) cnt = 0xFFFF; else cnt = (uint16_t) cnt32;
			put_s(utoa(cnt, cv, 10));				// 
			put_c(13);
			
#elif EXPORT == STRING_32
															// Ausgabe als ASCII-Zeichenfolge
			cnt32 /= teiler;							// durch 1 / 10 / 100 teilen
			put_s(ultoa(cnt32, cv, 10));			// ultoa ben�tigt viel Speicherplatz !!
			put_c(13);		
			
#elif EXPORT == DEZ_STRING							// als ASCII-Zeichenfolge mit Dezimalstellen
			ultoa(cnt32, cv, 10);					// Zahl in den String cv[] umwandeln
			if (teiler > 1)							// wenn der Teiler >1 (10 oder 100)
				{											// Dezimalpunkt am rechten Ende des Strings einf�gen
				if (teiler == 10) i = 1; else i = 2;
				Dez_Punkt(i);							// i gibt die Position des Dezimalpunktes an
				}											// vom rechten Ende aus gerechnet
			put_s(cv);
			put_c(13);
#else
#error EXPORT UNDEFINED
#endif
			}												// if (RS232_flag)
		
// --- Hier werden Schaltvorg�nge abh�ngig von der Helligkeit ausgef�hrt ------
#if SWITCH == TRUE	
		if (switch_flag)								// jedoch nur, wenn switch_flag == TRUE
			{
			// Achtung: cnt muss den Teiler ber�cksichtigen
			// und darf nicht > 2^16 sein. Siehe: --> EXPORT == STRING_16
			
			if (cnt < Limit_1_min) ALARM_1_SET; // Ein bei Unterscheitung von MIN
			else if (cnt > Limit_1_max) ALARM_1_CLR; // Aus bei �berschreitung von MAX

			if (cnt < Limit_2_min) ALARM_2_SET;// Ein bei Unterscheitung von MIN
			else if (cnt > Limit_2_max) ALARM_2_CLR;// Aus bei �berschreitung von MAX
// die umgekehrte Logik:
//			if (cnt < Limit_2_min) ALARM_2_CLR;// Aus bei Unterscheitung von MIN
//			else if (cnt > Limit_2_max) ALARM_2_SET;// Ein bei �berschreitung von MAX					
			}

		else												// damit der Alarm auch dann abgeschaltet wird
			{												// wenn nur das Flag gel�scht wird
			ALARM_1_CLR;								// ohne dass Grenzwerte �ber/unterschritten werden
			ALARM_2_CLR;
			} 												// if (switch_flag)
#endif
		if (LED_flag) LED_PORT |= (1<<LED_PIN);// LEDs wieder aus
		}
							
	else if (rx == 2)									// wenn genau 2 Byte empfangen wurden
		{													// dann pr�fen, ob ein Kommando vorliegt
															//	die Pause sollte nicht 0 Sekunden sein
		if      (rx_data[0] == CMD_PAUSE){  if (rx_data[1]) pause = rx_data[1];}
		else if (rx_data[0] == CMD_SLEEP){  sleep_flag  = rx_data[1];}
		else if (rx_data[0] == CMD_RS232){  RS232_flag  = rx_data[1];}
		else if (rx_data[0] == CMD_LED  ){  LED_flag    = rx_data[1];}
		else if (rx_data[0] == CMD_SWITCH){ switch_flag = rx_data[1];}
		}

#if DEBUG == TRUE
	else if (rx == 3)								// wenn drei beliebige Zeichen empfangen wurden
		{												// dann die aktuelle Einstellung/Status ausgeben
		put_c(13);
		put_s(utoa(pause, cv, 10));			// Zuerst die Pausendauer ausgeben
		if (sleep_flag) put_c('S'); else put_c('s');		// Gro�/Kleinschreibung f�r Ein-/Ausgeschaltet
		if (LED_flag) put_c('L'); else put_c('l');
	
#if SWITCH == TRUE								// die Einstellung der Schaltlimits ausgeben
		if (switch_flag) put_c('W'); else put_c('w');
		put_c('.');
		put_s(utoa(Limit_1_min, cv, 10));	// Schalter 1, Limit zum Abschalten
		put_c('.');
		put_s(utoa(Limit_1_max, cv, 10));	// Schalter 1, Limit zum Einschalten
		put_c('.');
		put_s(utoa(Limit_2_min, cv, 10));	// Schalter 2, Limit zum Abschalten
		put_c('.');
		put_s(utoa(Limit_2_max, cv, 10));	// Schalter 2, Limit zum Einschalten	
#endif
		}
#endif

#if SWITCH == TRUE
// --- bei rx == 5 werden Schaltschwellen �bertragen, sofern das CMD stimmt
	else if (rx == 5)
		{
		if (rx_data[0] == CMD_LIMIT_1)
			{
			Limit_1_min = (uint16_t) (rx_data[1] << 8) + rx_data[2];
			Limit_1_max = (uint16_t) (rx_data[3] << 8) + rx_data[4];
			}
		else if (rx_data[0] == CMD_LIMIT_2)
			{
			Limit_2_min = (uint16_t) (rx_data[1] << 8) + rx_data[2];
			Limit_2_max = (uint16_t) (rx_data[3] << 8) + rx_data[4];
			}
		}
#endif
	
// --- Hier wird ein SLEEP eingelegt - oder einfach nur gewartet --------------
	if (sleep_flag)
		{
		while(!(UCSRA & (1<<TXC) ));			// Solange noch ein Byte gesendet wird.
														// Es MUSS aber vorher mindestens ein Byte erfolgt gesendet worden sein, 
														// damit das Flag gesetzt ist !!! Darum das put_c(13) vor der Hauptschleife
#if INT0_ACTIV	== TRUE													
		GIMSK = (1<<INT0);						// INT0 aktivieren


														// INT_Activity_Flag dient dazu, Aktivit�ten am RS232 oder USI-IRQ
														// zu registrieren, weil dadurch die Messdauer beeinflu�t werden kann
														// Das wir hier benutzt um zu erkennen, wer den Interrupt ausgel�st hat,
														// der aus dem Sleep weckt.
														// Wenn das Flag nicht ge�ndert wurde, dann hat nicht der USI_IRQ zugeschlagen,
														// sondern der INT0.
		INT_Activity_Flag = INT_NO_ACTIVITY;	
		DISABLE_RX();								// Im Sleep-Modus den Empfang von Daten unterbinden
														// das funktioniert nicht
#endif
		asm volatile ("sleep");					// das Sleep wird durch ein USI-Start_IRQ unterbrochen
														// oder durch einen INT0_IRQ
																
#if INT0_ACTIV == TRUE
		GIMSK = 0;
														// Keine Ver�nderungen am Flag bedeuten, dass der INT0 ausgel�st wurde
														// daher das Flag zur Ausf�hrung einer neuen Messung setzen.
		if (INT_Activity_Flag == INT_NO_ACTIVITY) measure_flag = TRUE;
#endif
		}

	else												// kein sleep-flag - "free-running-Modus"
		{
		ENABLE_RX();								// Im "free-running-modus" den Empfang aktivieren
														// kann durch Wahl des Sleep-Modus abgeschaltet worden sein

		// wenn die Wartezeit nicht vorzeitig durch einen RX-/USI-Interrupt abgebrochen wird,
		// dann l�st das Flag measure_flag eine neue Messung aus.
		if (delay_1s(pause)) measure_flag = TRUE;
		}
	}													// while(1)
}														// main()


#if EXPORT == DEZ_STRING
// ---------------------------------------------------------------------------
// F�gt ein Zeichen (,) in die bestehende Zeichenfolge cv[] (Zahl als String) ein.
// Die Position des neuen Zeichens wird vom rechten Rand gemessen (Dezimalstelle).
// Ist die Ausgangsfolge zu kurz, dann wird sie auf der linken Seite
// mit '0' aufgef�llt, vor dem Dezmimaltrennzeichen wird eine '0' eingef�gt.
void Dez_Punkt(uint8_t n)
{

uint8_t i = 0, j;
int8_t k;

while(cv[i]) i++; 			// i = die L�nge des Ausgangsstrings ermitteln

k = i - n;						// pr�fen, ob die Zeichenfolge zu kurz f�r das Trennzeichen ist

while (k < 1)					// f�r jedes fehlende Zeichen 1x nach rechts schieben
	{
	i++;							// der String wird jeweils um 1 Zeichen l�nger
	j = i;						// zum Decrementieren eine Kopie von i anlegen
	while (j)
		{
		cv[j] = cv[j - 1];	// um eine Position nach rechts schieben
		j--;
		}
	cv[j] = '0';				// und links eine Null auff�llen
	k++;
	}

i++;								// ab dem einzuf�genden Zeichen alles nach rechts schieben
for (j = i; j >= (i-n); j--)
	{
	cv[j] = cv[j-1];			// um ein Zeichen nach rechts schieben
	}

cv[j] = DEZIMAL_PUNKT;		// bleibt noch das Zeichen einzuf�gen,
}									// der Bereich links davon bleibt unver�ndert
#endif

// ----------------------------------------------------------------------------
// wartet in einer Schleife
// wenn ein Interrupt (RX / USI) auftritt, dann wird in der jeweiligen ISR
// das Flag INT_Activity_Flag gesetzt:  Das f�hrt zum Abbruch der Warteschleife
// 
// liefert TRUE zur�ck, wenn die Wartezeit ohne Unterbrechung abgelaufen ist
// liefert FALSE, wenn ein Interrupt die Wartezeit unterbrochen hat
uint8_t delay_1s(uint8_t t)
{
uint8_t i;
INT_Activity_Flag = INT_NO_ACTIVITY;

while(t--)
	{
	i = 200;
	while(i--)
		{
		_delay_ms(5);
													// alle 5ms auf registrierten Interrupt pr�fen
		if (INT_Activity_Flag == INT_ACTIVITY) return(FALSE);
		}
	}

return(TRUE);
}


#if INT0_ACTIV == TRUE
// Auch ein INT0-Interrupt kann das Sleep beenden
// ----------------------------------------------------------------------------
EMPTY_INTERRUPT(INT0_vect); 
#endif


// --- [ eof ] ----------------------------------------------------------------

