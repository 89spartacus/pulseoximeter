// --- [ rs232_read_c.c ] -------------------------------------------------------
//
// Erwartet im Hintergrund (interruptgesteuert) Eingaben �ber die serielle Schnittstelle.
//
// Die empfangenen Daten werden in einem lokalen Puffer abgelegt.
// Sobald ein RETURN empfangen wird, wird das lokale Flag rx_flag gesetzt.
//
// Von aussen kann mit RX_Received_Bytes() gepr�ft werden, ob bzw. wieviele Bytes
// empfangen worden sind.
//
// Mit RX_Get_Data() werden dann die Daten abgeholt.
//
// Wenn der Puffer voll ist, dann werden keine Daten mehr �bernommen.
// Das INT_Activity_Flag zeigt an, ob sich ein RX-Interrupt ereignet hat.

#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>  
#include "rs232_read_c.h"
#include "global.h"

// --- lokale Variablen -------------------------------------------------------

uint8_t rx_buffer[RX_BUFFER_SIZE];
volatile  int8_t rx_head;
//volatile uint8_t rx_flag;
//#define rx_flag	GPIOR2      		// siehe global.h

// ----------------------------------------------------------------------------
// initialisiert die RS232-Schnittstelle
void RS232_init(void)
{
// ATTINY2313
UBRRL = TEILER;									// siehe rs232_int.h
UBRRH = 0;
UCSRC = (0<<UMSEL) | (1<<UCSZ1) | (1<<UCSZ0);
rx_flag = FALSE;
rx_head = -1;
ENABLE_RX();

}

// ATTINY2313
// ----------------------------------------------------------------------------
// wenn ein Byte via RS232 empfangen wurde, dann wird rx_flag auf TRUE gesetzt,
// dann wird es im Buffer abgelegt und der Pointer incrementiert.
// Wird ein RETURN erkannt, dann wird das Flag wieder rx_flag gel�scht.
// Solange wie das Flag gesetzt ist, l�uft eine �bertragung.
ISR (USART_RX_vect)
{
uint8_t i;
i = UDR;											// UDR kann nur 1x ausgelesen werden

													// den Index incrementieren, 
													// sofern der Puffer noch nicht voll
if (rx_head < (RX_BUFFER_SIZE - 1))	rx_head++;

if (i == 13)	 								// wenn ein RETURN empfangen wird					
	{
	rx_flag = FALSE;							// das Flag l�schen
	}
else
	{
	rx_flag = TRUE;							// das Flag w�hrend der �bertragung gesetzt halten
	rx_buffer[rx_head] = i;				   // die Daten speichern
	}

INT_Activity_Flag = INT_ACTIVITY;		// Der Interrupt war aktiv, es wurden Daten empfangen !
}

// ---------------------------------------------------------------------------
// Wenn die �bertragung im Gange ist (rx_flag = TRUE) und noch nicht mit einem Return 
// abgeschlossen ist,
// dann wird gewartet, bis ein RETURN empfangen wurde (rx_flag = FALSE)
// Anschlie�end wird die Anzahl der empfangenen Bytes im Puffer zur�ckgegeben.
//
// Falls keine Transaktion l�uft, dann wird rx_head (= 0) zur�ckgegeben.
int8_t RX_Received_Bytes(void)
{
while(rx_flag);								// warten, solange die �bertragung l�uft
return(rx_head);								// den Index zur�ckgeben
}

// ---------------------------------------------------------------------------
// liefert die empfangenen Bytes via Array zur�ck und l�scht die Pointer/Flags
// damit diese Daten nicht noch ein weiteres Mal ausgelesen werden.
// Die Anzahl der Bytes steht in rx_head
// Das letzte Byte ist das abschlie�ende RETURN !!!
void RX_Get_Data(uint8_t * data)
{
uint8_t i = 0;

do	{
	data[i] = rx_buffer[i];
	} while ((i++) < rx_head) ;

rx_head = -1;									// keine Daten mehr vorhanden

}

// --- Standard-RS232-Routinen --- ATTINY2313 ---------------------------------
// ----------------------------------------------------------------------------
// ein einzelnes Zeichen auf COM ausgeben
void put_c(uint8_t Zeichen)
{
while(!(UCSRA & (1<<UDRE)));
UCSRA |= (1<<TXC);							// Flag TXC l�schen f�r die Auswertung vor dem Sleep
UDR = Zeichen;
}


// ----------------------------------------------------------------------------
// einen String auf COM ausgeben
void put_s(char *s)
{
while(*s)
	{
	put_c(*s);
	s++;
	}
}

// --- [ eof ] ----------------------------------------------------------------

