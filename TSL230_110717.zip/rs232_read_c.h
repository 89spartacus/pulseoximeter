// --- [ rs232_read_c.h ] -------------------------------------------------------

void	RS232_init(void);
void 	put_c(uint8_t);
void 	put_s(char *s);

int8_t RX_Received_Bytes(void);
void   RX_Get_Data(uint8_t * data);

#define RX_BUFFER_SIZE		16
#define TX_BUFFER_SIZE		16

#define BAUD  	9600
#define TEILER ((F_CPU /(BAUD * 16l)) -1)

// Register USCRB konfigurieren (ATTINY2313)
#define ENABLE_RX() 	(UCSRB = (1<<RXCIE | 0<<TXCIE | 0<<UDRIE | 1<<RXEN | 1<<TXEN))
#define DISABLE_RX()	(UCSRB = (0<<RXCIE | 0<<TXCIE | 0<<UDRIE | 0<<RXEN | 1<<TXEN))

// --- [ eof ] ----------------------------------------------------------------
