// This file has been prepared for Doxygen automatic documentation generation.
/*! \file ********************************************************************
*
* Atmel Corporation ### --- MODIFIZIERTE VERSION --- ###
*
* File              : USI_TWI_Slave_b.c
* Compiler          : IAR EWAAVR 4.11A
* Revision          : $Revision: 1.14 $
* Date              : $Date: Friday, December 09, 2005 17:25:38 UTC $
* Updated by        : $Author: jtyssoe $
*
* Supported devices : All device with USI module can be used.
*
* AppNote           : AVR312 - Using the USI module as a I2C slave
*
* Description       : Functions for USI_TWI_receiver and USI_TWI_transmitter.
*
* �NDERUNG:  zus�tzliches TWI_state (0) eingef�gt
*            zus�tzliche Abfrage, ob Daten empfangen wurden
*            die R�ckgabe ist -1 (keine Daten), 0 (nur g�ltige Adresse) >0 (Anzahl Bytes)
*            nicht ben�tigte Funktionen entfernt,
*				 bei einem TWI-Start (+read)  wird TWI_TxHead zur�ckgesetzt,
*            bei einem TWI-Start (+read oder +write) wird TWI_RxHead auf 0 gesetzt
*            TWI_RxHead ist integer und default auf -1
****************************************************************************/

#include <avr/io.h>
#include <avr/interrupt.h>
#include "USI_TWI_slave_c.h"  // ge�nderte Include-Datei
#include "global.h"

uint8_t TWI_RxBuf[TWI_RX_BUFFER_SIZE];
uint8_t TWI_TxBuf[TWI_TX_BUFFER_SIZE];
volatile  int8_t TWI_RxHead;
volatile uint8_t TWI_TxHead;

// volatile uint8_t USI_TWI_State;  // siehe global.h
// #define USI_TWI_State GPIOR0  	// siehe global.h

// volatile uint8_t USI_activity_flag;  // siehe global.h
// #define USI_activity_flag GPIOR2  // siehe global.h

// Um von aussen zu erkennen, ob es Aktivit�ten
// auf dem USI-TWI-Bus gegeben hat
// -> die Interrupts k�nnen das Messintervall verl�ngert haben,
//    eine neue Messung ist erforderlich

/* 

Nur eine USI_Start_ISR kann aus dem Sleep wecken (nicht die USI_OVERFLOW_ISR) !
Daher muss - bevor wieder in den Sleep-Modus gefallen wird - der Abschluss
der �bertragung abgewartet werden.

Der wird signalisiert durch:
-> USI_TWI_State == USI_SLAVE_WAITING
	Dieser State wird im Programm gesetzt, wenn
	- der Master gesendete Daten mit einem NACK quittiert,
	- eine andere als die eigene TWI-Adresse angesprochen wird,
Im Programmablauf kann nicht erkannt werden, wenn der Master nach dem Senden von Daten an den Slave
die �bertragung mit einem STOP beendet (denn dann tritt kein weiterer USI_Overflow_INT auf).
Zur Erkennung dieses Stops muss das Flag USIPF in USISR ausgewertet werden.
(USISR & (1<<USIPF) == TRUE) (wenn ein USI_Stop erkannt wurde)

Nach einer USI_START_ISR wird daher gewartet, bis
entweder der USI_TWI_State == 0 oder das Flag USIPF in USISR gesetzt ist.

	while (( USI_TWI_State) && (!(USISR & (1<<USIPF))));

*/

/*

Ein anderes Problem entsteht, wenn eine Messung, die �ber ein festes Zeitintervall auszuf�hren ist, 
durch eine USI_TWI_ISR oder den Empfang serieller Daten unterbrochen wird.
Die ISR k�nnte u.U. das Messintervall verl�ngern, wenn der Timer nicht rechtzeitig
die Messung beenden kann.
Zur Vermeidung wird zu Beginn einer Messung ein Flag auf TRUE gesetzt, dass bei jedem Aufruf
der USI_TWI_ISR auf FALSE zur�ckgesetzt wird.
Am Ende der Messung wird gepr�ft, ob das Flag noch auf TRUE steht - wenn ja, dann hat  
es keine Aktivit�ten am USI-Bus w�hrend der Messzeit gegeben.

Das Flag wird ausserdem genutzt, um die Warteschleifen (delay_ms()) zwischen den Messungen
durch Senden oder Abholen von Daten unterbrechen zu k�nnen.

*/

// ---------------------------------------------------------------------------
void USI_TWI_Slave_Initialise( void )
{

USI_TWI_State = USI_SLAVE_WAITING;

PORT_USI |=  (1<<PORT_USI_SCL);                   // Set SCL high
PORT_USI |=  (1<<PORT_USI_SDA);                   // Set SDA high
DDR_USI  |=  (1<<PORT_USI_SCL);                   // Set SCL as output
DDR_USI  &= ~(1<<PORT_USI_SDA);                   // Set SDA as input
USICR     =  (1<<USISIE)|(0<<USIOIE)|             // Enable Start Condition Interrupt. Disable Overflow Interrupt.
             (1<<USIWM1)|(0<<USIWM0)|             // Set USI in Two-wire mode. No USI Counter overflow prior
                                                  // to first Start Condition (potentail failure)
             (1<<USICS1)|(0<<USICS0)|(0<<USICLK)| // Shift Register Clock Source = External, positive edge
             (0<<USITC);
USISR    = 0xF0;                                  // Clear all flags and reset overflow counter
TWI_RxHead = -1;											  // keine Daten empfangen
}

// ---------------------------------------------------------------------------
// Gibt zur�ck, ob wieviele Bytes im Empfangspuffer vorhanden ist.
// Wenn eine �bertragung noch nicht abgeschlossen ist, dann wird bis zu deren Ende gewartet.
// Wenn USI_TWI_State > 0, dann l�uft eine �bertragung

// R�ckgabe:
// -1		wenn keine Daten oder eine ung�ltige Adresse empfangen wurden
//  0		wenn nur eine g�ltige Adresse (mit oder ohne RW-Bit) empfangen wurde
// >0    die Anzahl der empfangenen Bytes

// wenn die R�ckgabe > 0, dann m�ssen die empfangenen Daten abgeholt 
// und dabei der Index TWI_RxHead wieder auf -1 gesetzt werden

int8_t USI_TWI_Received_Bytes( void )
{
	while (( USI_TWI_State) && (!(USISR & (1<<USIPF)))); // warten bis zum Abschluss
	return (TWI_RxHead);
}

// ---------------------------------------------------------------------------
// Holt die empfangenen Daten ab,
// Die Anzahl steht in TWI_RxHead
// vorher muss mit USI_TWI_Received_Bytes() gep�ft werden, ob Daten vorhanden sind

void USI_TWI_Get_Data(uint8_t * data)
{
uint8_t i = 0;
do {
	data[i] = TWI_RxBuf[i];
	}
	while (++i < TWI_RxHead);
	TWI_RxHead = -1;							// damit die Daten nur 1x gelesen werden
}

// ---------------------------------------------------------------------------
// Kopiert Daten in den lokalen Sendespeicher zur Abholung durch den Master
void USI_TWI_Transmit_Data(uint8_t * data, uint8_t cnt)
{
uint8_t i;
// if (cnt > TWI_TX_BUFFER_SIZE) cnt = TWI_TX_BUFFER_SIZE;  // zur Sicherheit
for (i = 0; i < cnt; i++) TWI_TxBuf[i] = data[i];
}

// ---------------------------------------------------------------------------
// wird jeweils einmal am Beginn einer USI-TWI-Transaktion aufgerufen
ISR(USI_START_VECTOR)
{
   unsigned char tmpUSISR;                            // Temporary variable to store volatile
   tmpUSISR = USISR;                                  // Not necessary, but prevents warnings
																		// Set default starting conditions for new TWI package
   USI_TWI_State = USI_SLAVE_CHECK_ADDRESS;
   DDR_USI  &= ~(1<<PORT_USI_SDA);                    // Set SDA as input
   while ( (PIN_USI & (1<<PORT_USI_SCL)) & !(tmpUSISR & (1<<USIPF)) );
																		// Wait for SCL to go low to ensure the "Start Condition" has completed.
                                                      // If a Stop condition arises then leave the interrupt to prevent waiting forever.
   USICR  = (1<<USISIE)|(1<<USIOIE)|                  // Enable Overflow and Start Condition Interrupt. (Keep StartCondInt to detect RESTART)
            (1<<USIWM1)|(1<<USIWM0)|                  // Set USI in Two-wire mode.
            (1<<USICS1)|(0<<USICS0)|(0<<USICLK)|      // Shift Register Clock Source = External, positive edge
            (0<<USITC);
   USISR  = (1<<USI_START_COND_INT)|(1<<USIOIF)|(1<<USIPF)|(1<<USIDC)|      // Clear flags
            (0x0<<USICNT0);                           // Set USI to sample 8 bits i.e. count 16 external pin toggles.
	
	INT_Activity_Flag = INT_ACTIVITY;						// Nur f�r Messungen mit dem TSL230

}

// ---------------------------------------------------------------------------
// wird w�hrend der USI-TWI-Transaktion aufgerufen, wenn 8Bit �bertragen worden sind
ISR(USI_OVERFLOW_VECTOR)
{

	INT_Activity_Flag = INT_ACTIVITY;						// Nur f�r Messungen mit dem TSL230
   switch (USI_TWI_State)
  {
   // ---------- Address mode -------------------------------------------------

   // Check address and send ACK (and next USI_SLAVE_SEND_DATA) if OK, else reset USI.
    case USI_SLAVE_CHECK_ADDRESS:

      if (( USIDR >> 1) == (TWI_SLA_ADR >> 1))  // Mit Konstante vergleichen ( spart eine Variable ! )
			{
			TWI_RxHead = 0;						// wird auf 0 gesetzt, wenn die Adresse stimmt 
			if ( USIDR & 0x01 )					// wenn Bit.0 gesetzt ist, dann wird vom Master gelesen
				{
				USI_TWI_State = USI_SLAVE_SEND_DATA;										
				TWI_TxHead = 0;							
				} 

			else										// der Master sendet, der Slave empf�ngt
				{ 									
				USI_TWI_State = USI_SLAVE_REQUEST_DATA;
				} 
				
			SET_USI_TO_SEND_ACK();
			}											// beim Lesen des TX_Buffer

      else											// falsche Adresse - Beenden
			{
			USI_TWI_State = USI_SLAVE_WAITING; // USI_TWI_State zur�cksetzen
			SET_USI_TO_TWI_START_CONDITION_MODE();
			}
		break;

   // ----- Slave Send Data Mode ---------------------------------------------
	
   // Check reply and goto USI_SLAVE_SEND_DATA if OK, else reset USI.
   case USI_SLAVE_CHECK_REPLY_FROM_SEND_DATA:
      if ( USIDR ) // If NACK, the master does not want more data.
			{
			USI_TWI_State = USI_SLAVE_WAITING; // Erg�nzung
			SET_USI_TO_TWI_START_CONDITION_MODE();
			break;
			}

	// From here we just drop straight into USI_SLAVE_SEND_DATA if the master sent an ACK

   // Copy data from buffer to USIDR and set USI to shift byte. Next USI_SLAVE_REQUEST_REPLY_FROM_SEND_DATA
   case USI_SLAVE_SEND_DATA:
		USIDR = TWI_TxBuf[TWI_TxHead];
      TWI_TxHead = ((TWI_TxHead + 1) & TWI_TX_BUFFER_MASK);
      USI_TWI_State = USI_SLAVE_REQUEST_REPLY_FROM_SEND_DATA;
      SET_USI_TO_SEND_DATA();
      break;

   // Set USI to sample reply from master. Next USI_SLAVE_CHECK_REPLY_FROM_SEND_DATA
   case USI_SLAVE_REQUEST_REPLY_FROM_SEND_DATA:
      USI_TWI_State = USI_SLAVE_CHECK_REPLY_FROM_SEND_DATA;
      SET_USI_TO_READ_ACK();
      break;

   // ----- Slave Read Data Mode ---------------------------------------------
	
   // Set USI to sample data from master. Next USI_SLAVE_GET_DATA_AND_SEND_ACK.
   case USI_SLAVE_REQUEST_DATA:
      USI_TWI_State = USI_SLAVE_GET_DATA_AND_SEND_ACK;
      SET_USI_TO_READ_DATA();
      break;

   // Copy data from USIDR and send ACK. Next USI_SLAVE_REQUEST_DATA
   case USI_SLAVE_GET_DATA_AND_SEND_ACK:
      TWI_RxBuf[TWI_RxHead]  = USIDR;
      TWI_RxHead = ( TWI_RxHead + 1 ) & TWI_RX_BUFFER_MASK;
      USI_TWI_State = USI_SLAVE_REQUEST_DATA;
      SET_USI_TO_SEND_ACK();
      break;
	}
}

// --- [ eof ] ----------------------------------------------------------------
