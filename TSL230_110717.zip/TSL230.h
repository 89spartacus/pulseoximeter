// --- [ TSL230.h ] -----------------------------------------------------------
//
//       tab = 3  

#ifndef EXTERN
#define EXTERN extern
#endif

void TSL_Init(void);
void TSL_Count(uint32_t * cnt32, uint8_t * teiler);
void TSL_Power_Down(void);
void TSL_Power_Up(void);

#define TSL_PORT					PORTB
#define TSL_DDR					DDRB


#define TSL_S0_PIN				PB0
#define TSL_S1_PIN				PB1
#define TSL_S2_PIN				PB2
#define TSL_S3_PIN				PB3

/*
#define TSL_S0_PIN				PB3
#define TSL_S1_PIN				PB2
#define TSL_S2_PIN				PB1
#define TSL_S3_PIN				PB0
*/

//#define TSL_OE_PIN				PB4	// wird direkt mit gnd verbunden !!

#define TSL_SENSITIVITY_PD		0
#define TSL_SENSITIVITY_1		1	
#define TSL_SENSITIVITY_10		10
#define TSL_SENSITIVITY_100	100

#define TSL_SCALING_1			1
#define TSL_SCALING_2			2
#define TSL_SCALING_10			10
#define TSL_SCALING_100			100

// --- [eof ] -----------------------------------------------------------------